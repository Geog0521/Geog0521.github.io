# This is a sample Python script for calculating Boltzmann entropy.
import cal_Boltzmann_entropy as fb
import numpy as np
from osgeo import gdal

def cal_Boltzmann_entropy(test=True):


    data = np.array([[1, 2, 3, 4], [11, 12, 13, 14], [5, 6, 7, 8], [25, 26, 27, 28]])

    # example (i)
    #method = "resampling" is_relative=True
    #we use the resampling-based method to calculate relative Boltzmann entropy of numerical raster data
    #is_normalize=True: the relative Boltzmann entropy is divided by the image size (e.g.,4*4)
    bnu = fb.BoltzNumerical(data)
    rela_BE_resampl = bnu.get_boltzmann_numerical(method='resampling', is_relative=True, is_normalize=True)
    print("relative Boltzmann entropy of data with the use of the resampling-based method:{}".format(rela_BE_resampl))

    # method = "aggregation" is_relative=True
    # we use the aggregation-based method to calculate relative Boltzmann entropy of numerical raster data
    # is_normalize=True: the relative Boltzmann entropy is divided by the image size (e.g.,4*4)
    bnu = fb.BoltzNumerical(data)
    rela_BE_aggre = bnu.get_boltzmann_numerical(method='aggregation', is_relative=True, is_normalize=True)
    print("relative Boltzmann entropy of data with the use of the aggregation-based method:{}".format(rela_BE_aggre))

    # method = "resampling" is_relative = False
    # we use the resampling-based method to calculate absolute Boltzmann entropy of numerical raster data
    # is_normalize=True: the relative Boltzmann entropy is divided by the image size (e.g.,4*4)
    bnu = fb.BoltzNumerical(data)
    abs_BE_resampl = bnu.get_boltzmann_numerical(method='resampling', is_relative=False, is_normalize=True)
    print("absolute(multiscale) Boltzmann entropy of data with the use of the resampling-based method:{}".format(abs_BE_resampl))

    # method = "resampling" is_relative = False
    # we use the aggregation-based method to calculate absolute Boltzmann entropy of numerical raster data
    # is_normalize=True: the relative Boltzmann entropy is divided by the image size (e.g.,4*4)
    bnu = fb.BoltzNumerical(data)
    print("data shape:{}".format(data.shape))
    abs_BE_agg = bnu.get_boltzmann_numerical(method='aggregation', is_relative=False, is_normalize=True)
    print("absolute(multiscale) Boltzmann entropy of data with the use of the aggregation-based method:{}".format(abs_BE_agg))

    ####################################################################################################
    #Given the real image data, we give a calculation example
    ####################################################################################################
    from osgeo import gdal
    # the data type of "example_multisepctral_image.tif" is numerical.
    data = gdal.Open('./data_examples/example_multisepctral_image.tif').ReadAsArray()
    entropy_band_list = []
    print("data shape:{}".format(data.shape))
    for i in range(data.shape[0]):
        input_data = data[i, :, :]
        bnu = fb.BoltzNumerical(input_data)
        entropy = bnu.get_boltzmann_numerical(method='resampling', is_relative=True, is_normalize=True)
        entropy_band_list.append(entropy)
    Be_multisep_img = sum(entropy_band_list)/data.shape[0]
    print("Boltzmann entropy of the (multisepctral image file)tif file:{}".format(Be_multisep_img))

    #the data type of "example_categorical_map.tif" is nominal.
    data = gdal.Open('./data_examples/example_categorical_map.tif').ReadAsArray()
    bno = fb.BoltzNominal(data)
    #is_normalize_category=True: the relative Boltzmann entropy is divided by the total number of classes
    #is_normalize_size=True: the relative Boltzmann entropy is divided by the data size
    entropy = bno.get_boltzmann_nominal(is_normalize_category=True, is_normalize_size=True)
    print("Boltzmann entropy of the (map)tif file:{}".format(entropy))



# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print("start calculating Boltzmann entropy")
    cal_Boltzmann_entropy()

